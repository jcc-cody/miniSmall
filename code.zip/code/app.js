App({
	// 注册小程序
	onLauch(){
		console.log('程序开启');
	},
	data: {
		isMusicPlay: false,
		playPageIndex: null,
		movies: []
	}
})